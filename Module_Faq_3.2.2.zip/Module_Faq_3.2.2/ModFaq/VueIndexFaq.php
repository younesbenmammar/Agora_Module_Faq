<!-- Ce module FAQ a été créé durant un stage à ZOOMACOM par un étudiant en formation -->
<!-- à la Design Tech Academie Télécom Saint-Etienne à partir du module Forum d'Agora-Project -->

<script>
    $(function(){
        //Active/désactive les notifications des messages par mail
        <?php if($displayFaq=="subjectMessages"){ ?>
        $("#notifyLastMessage").click(function(){
            $.ajax("?ctrl=faq&action=notifyLastMessage&targetObjId=<?= $curSubject->_targetObjId ?>").done(function(ajaxResult){
                if(ajaxResult=="addUser")    {$("#notifyLastMessage").addClass("vNotifyLastMessageSelect");}
                else                        {$("#notifyLastMessage").removeClass("vNotifyLastMessageSelect");}
            });
        });
        //Selectionne "Me notifier par email"?
        if("<?= (int)$curSubject->curUserNotifyLastMessage() ?>"=="1")  {$("#notifyLastMessage").addClass("vNotifyLastMessageSelect");}
        <?php } ?>
    });
</script>

<style>
    /*General*/
    .pageModMenuContainer{<?= ($pageFullOrCenter=="pageCenter") ? "display:none" : null ?>}
    .objLines .objContainer            {height:auto!important; padding-right:50px!important;}/*surcharge: hauteur auto pour afficher tout le texte!*/
    .objLines .objContent>div        {padding:10px;}
    .vObjDetails                    {white-space:nowrap; line-height:20px; text-align:right;}
    .vObjDetails hr                    {display:none;}
    /*Themes*/
    .vThemeTitle                    {text-transform:uppercase;}
    .vThemeDescription                {margin-top:7px; font-weight:normal;}
    /*Sujet & Message*/
    .vSubjectMessages>div            {vertical-align:top!important;}
    .vSubjMessDescription            {margin-top:10px; font-weight:normal;}
    .vSubjMessQuote                    {margin-right:8px;}
    .vSubjectContainer .objContent, .vMessageContainer .objContent    {cursor:default!important;}
    .vSubjectContainer                {margin-bottom:5px!important;}
    .vMessageQuoted                    {display:inline-block; overflow:auto; max-height:100px; margin-bottom:10px; padding:8px 15px 8px 15px; border-radius:5px; font-style:italic; background-color:<?= Ctrl::$agora->skin=="black"?"#333":"#eee" ?>;}
    .vMessageQuoted [src*='quote']    {float:right; opacity:0.5;}
    .vNotifyLastMessageSelect        {color:#a00; font-style:italic;}
    .objContent hr                    {background:linear-gradient(to right,<?= Ctrl::$agora->skin=="black"?"#888":"#eee" ?>,transparent)!important; margin:0px;}
    .objBottomMenu>div                {min-width:150px;}

    /*RESPONSIVE*/
    @media screen and (max-width:1005px){
        .objLines .objContainer            {padding-right:35px!important;}
        .objContent, .objContent>div    {display:inline-block; width:100%!important;}/*surcharge*/
        .vObjDetails                    {text-align:left; white-space:normal;}
        .vObjDetails hr                    {display:block; margin-bottom:5px;}
</style>

<div class="<?= $pageFullOrCenter ?>">
    <div class="pageModMenuContainer">
        <div id="pageModMenu" class="sBlock">
            <?php
            ////    MENU DES SUJETS
            if($displayFaq=="subjects"){
                $tradSubjects=($subjectsTotalNb>1) ? "Faq_subjects" : "Faq_subject";
                if(MdlFaqSubject::addRight())  {echo "<div class='menuLine sLink' onclick=\"lightboxOpen('".MdlFaqSubject::getUrlNew()."&_idTheme=".Req::getParam("_idTheme")."');\"><div class='menuIcon'><img src='app/img/plus.png'></div><div>".Txt::trad("Faq_addSubject")."</div></div><hr>";}
                echo MdlFaqSubject::menuSort();
                echo "<div class='menuLine'><div class='menuIcon'><img src='app/img/info.png'></div><div>".$subjectsTotalNb." ".Txt::trad($tradSubjects)."</div></div>";
            }
            ////    EDIT LES THEMES
            if(!empty($editTheme))
            {echo "<div class='menuLine sLink' onclick=\"lightboxOpen('?ctrl=faq&action=FaqThemeEdit');\"><div class='menuIcon'><img src='app/img/category.png'></div><div>".Txt::trad("Faq_editThemes")."</div></div>";}
            ////    MENU D'UN SUJET ET SES MESSAGES
            if($displayFaq=="subjectMessages"){
                if(Ctrl::$curContainer->editContentRight())    {echo "<div class='menuLine sLink' onclick=\"lightboxOpen('".MdlFaqMessage::getUrlNew()."');\"><div class='menuIcon'><img src='app/img/plus.png'></div><div>".Txt::trad("Faq_addMessage")."</div></div>";}
                if(!empty(Ctrl::$curUser->mail))            {echo "<div class='menuLine sLink' id='notifyLastMessage' title=\"".Txt::trad("Faq_notifyLastPostInfo")."\"><div class='menuIcon'><img src='app/img/mail.png'></div><div>".Txt::trad("Faq_notifyLastPost")."</div></div>";}
                echo "<hr>".MdlFaqMessage::menuSort()."<div class='menuLine'><div class='menuIcon'><img src='app/img/info.png'></div><div>".$curSubject->messagesNb." ".Txt::trad($curSubject->messagesNb>1?"Faq_messages":"Faq_message")."</div></div>";
            }
            ?>
        </div>
    </div>

    <div class="objLines <?= ($displayForum=="theme" && empty($editTheme))?"pageCenterContent":"pageFullContent" ?>">
        <?php
        ////    PATH DU Faq (ACCUEIL Faq > THEME COURANT > SUBJET COURANT)
        if(!empty($curTheme) || !empty($curSubject)){
            $curThemeLink=(!empty($curTheme))  ?  "<div><img src='app/img/arrowRightPath.png'></div><a href=\"?ctrl=faq&_idTheme=".$curTheme->idThemeUrl."\">".Txt::reduce($curTheme->display(),25)."</a>"  :  null;
            $curSubjectTitle=(!empty($curSubject))  ?  "<div><img src='app/img/arrowRightPath.png'></div><a>".Txt::reduce($curSubject->title?$curSubject->title:$curSubject->description,25)."</a>"  :  null;
            echo "<div class='pathMenu sBlock'><div><img src='app/img/faq/iconSmall.png'></div><a href='?ctrl=faq'>".Txt::trad("Faq_forumRoot")."</a>".$curThemeLink.$curSubjectTitle."</div>";
        }

        ////    THEMES
        if($displayFaq=="theme")
        {
            foreach($themeList as $tmpTheme)
            {
                //Init
                $subjectsNb=$messagesNb="&nbsp;";
                if(!empty($tmpTheme->subjectsNb))    {$subjectsNb=$tmpTheme->subjectsNb." ".Txt::trad($tmpTheme->subjectsNb>1?"Faq_subjects":"Faq_subject").".&nbsp; ".Txt::trad("Faq_lastPost")." ".$tmpTheme->subjectLast->displayAutor().", ".$tmpTheme->subjectLast->displayDate();}
                if(!empty($tmpTheme->messagesNb))    {$messagesNb=$tmpTheme->messagesNb." ".Txt::trad($tmpTheme->messagesNb>1?"Faq_messages":"Faq_message").".&nbsp; ".Txt::trad("Faq_lastPost")." ".$tmpTheme->messageLast->displayAutor().", ".$tmpTheme->messageLast->displayDate();}
                //Affichage
                echo "<div class='objContainer sBlock' onClick=\"redir('?ctrl=faq&_idTheme=".$tmpTheme->idThemeUrl."')\">
                        <div class='objContent sLink vThemes'>
                            <div><div class='vThemeTitle'>".$tmpTheme->display()."</div><div class='vThemeDescription'>".$tmpTheme->description."</div></div>
                            <div class='vObjDetails'><div>".$subjectsNb."</div><div>".$messagesNb."</div></div>
                        </div>
                    </div>";
            }
        }

        ////    SUJETS
        if($displayFaq=="subjects")
        {
            foreach($subjectsDisplayed as $tmpSubject)
            {
                //Init
                $subjectStyle=($tmpSubject->curUserLastMessageIsNew())  ?  "sLinkSelect"  :  "sLink";
                $displayedTitle=(!empty($tmpSubject->title))  ?  $tmpSubject->title."<hr>"  :  null;
                $nbMessagesLastPost=$tmpSubject->messagesNb." ".Txt::trad($tmpSubject->messagesNb>1?"Faq_messages":"Faq_message");
                if(!empty($tmpSubject->messagesNb))  {$nbMessagesLastPost.=" : ".Txt::trad("Faq_lastPost")." ".$tmpSubject->messageLast->displayAutor().", ".$tmpSubject->messageLast->displayDate();}
                //Affichage
                echo $tmpSubject->divContainer("alternateLines").$tmpSubject->contextMenu().
                    "<div class='objContent vSubjects ".$subjectStyle."' onclick=\"redir('?ctrl=faq&targetObjId=".$tmpSubject->_targetObjId."')\" title=\"".Txt::trad("Faq_displaySubject")."\">
                        <div>".
                    $displayedTitle.
                    "<div class='vSubjMessDescription'>".Txt::reduce(strip_tags($tmpSubject->description),200)."</div>
                        </div>
                        <div class='vObjDetails'>
                            <div>".Txt::trad("postBy")." ".$tmpSubject->displayAutor().", ".$tmpSubject->displayDate()."</div>
                            <div>".$nbMessagesLastPost."</div>
                        </div>
                    </div>
                </div>";
            }
            ////    AUCUN SUJET  /  MENU DE PAGINATION
            if(empty($subjectsDisplayed))  {echo "<div class='pageEmptyContent'>".Txt::trad("Faq_noSubject")."</div>";}
            echo MdlFaqSubject::menuPagination($subjectsTotalNb,"_idTheme");
        }

        ////    SUJET COURANT & MESSAGES ASSOCIES
        if($displayFaq=="subjectMessages")
        {
            ////SUJET
            $displayedTitle=(!empty($curSubject->title))  ?  $curSubject->title."<hr>"  :  null;
            echo $curSubject->divContainer("vSubjectContainer").$curSubject->contextMenu().
                "<div class='objContent vSubjectMessages'>
                        <div>".
                $displayedTitle.
                "<div class='vSubjMessDescription'>".$curSubject->description.$curSubject->menuAttachedFiles()."</div>
                        </div>
                        <div class='vObjDetails'><hr>".$curSubject->displayAutorDate(true)."</div>
                    </div>
                </div>";
            ////MESSAGES DU SUJET
            foreach($subjectMessages as $tmpMessage)
            {
                //Init
                $displayedTitle=$quotedMessage=null;
                if(!empty($tmpMessage->title))        {$displayedTitle=$tmpMessage->title."<hr>";}
                if($curSubject->editContentRight())    {$displayedTitle="<a href=\"javascript:lightboxOpen('".MdlFaqMessage::getUrlNew()."&_idMessageParent=".$tmpMessage->_id."')\" title=\"".Txt::trad("Faq_quoteMessage")."\" class='vSubjMessQuote'><img src='app/img/forum/quoteReponse.png'></a>".$displayedTitle;}
                if(!empty($tmpMessage->_idMessageParent))    {$quotedMessage="<div class='vMessageQuoted'><img src='app/img/forum/quote.png'>".Ctrl::getObj($tmpMessage::objectType,$tmpMessage->_idMessageParent)->title."<br>".Ctrl::getObj($tmpMessage::objectType,$tmpMessage->_idMessageParent)->description."</div><br>";}
                //Affichage
                echo $tmpMessage->divContainer("vMessageContainer alternateLines","data-treeLevel='".$tmpMessage->treeLevel."'").$tmpMessage->contextMenu().
                    "<div class='objContent vSubjectMessages'>
                            <div>".$displayedTitle."<div class='vSubjMessDescription'>".$quotedMessage.$tmpMessage->description.$tmpMessage->menuAttachedFiles()."</div>
                            </div>
                            <div class='vObjDetails'><hr>".$tmpMessage->displayAutorDate(true)."</div>
                        </div>
                    </div>";
            }
            ////REPONDRE AU SUJET
            if(Ctrl::$curContainer->editContentRight())    {echo "<div class='objBottomMenu'><div class='sBlock sLink' onclick=\"lightboxOpen('".MdlFaqMessage::getUrlNew()."');\"><img src='app/img/plus.png'> ".Txt::trad("Faq_addMessage")."</div></div>";}
        }
        ?>
    </div>
</div>


