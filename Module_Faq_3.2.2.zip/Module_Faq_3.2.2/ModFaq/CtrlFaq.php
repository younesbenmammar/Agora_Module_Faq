<?php
/**
* This file is part of the Agora-Project Software package.
*
* @copyright (c) Agora-Project Limited <https://www.agora-project.net>
* @license GNU General Public License, version 2 (GPL-2.0)
*/

// Ce module FAQ a été créé durant un stage à ZOOMACOM par un étudiant en formation
// à la Design Tech Academie Télécom Saint-Etienne à partir du module Forum d'Agora-Project

/*
 * Controleur du module "Forum"
 */

class CtrlFaq extends Ctrl
{
    const moduleName = "faq";
    public static $moduleOptions = ["ajout_sujet_admin", "ajout_sujet_theme"];
    public static $MdlObjects = array("MdlFaqSubject", "MdlFaqMessage");

    /*
     * ACTION PAR DEFAUT
     */
    public static function actionDefault()
    {
        //Init
        $vDatas["themeList"] = MdlFaqTheme::getThemes();
        $vDatas["pageFullOrCenter"] = "pageFull";
        ////	AFFICHAGE D'UN SUJET & SES MESSAGES(?)
        $curSubject = Ctrl::getTargetObj();
        if (is_object($curSubject) && $curSubject::objectType == "faqSubject")

        {

			$curSubject->curUserConsultLastMessageMaj();//Met à jour si besoin la consultation du dernier message
			$vDatas["subjectMessages"]=$curSubject->getMessages();
			$vDatas["curSubject"]=$curSubject;
			$vDatas["displayFaq"]="subjectMessages";

        }
        ////	AFFICHAGE DES THÈMES DE SUJET
        elseif (!empty($vDatas["themeList"]) && Req::isParam("_idTheme") == false) {


            $vDatas["displayFaq"] = "theme";
            $vDatas["editTheme"] = MdlFaqTheme::addRight();

            if ($vDatas["editTheme"] == false) {$vDatas["pageFullOrCenter"] = "pageCenter";}
            $vDatas["themeList"][] = new MdlFaqTheme(["undefinedTheme" => true]);//ajoute le pseudo theme "sans theme"

            foreach ($vDatas["themeList"] as $tmpKey => $tmpTheme) {
                //Nombre de sujets & Objet du dernier sujet

                $sqlThemeFilter = (!empty($tmpTheme->_id)) ? "_idTheme=" . $tmpTheme->_id : "_idTheme is NULL";//Theme normal / "sans theme"

                $tmpTheme->subjectList = Db::getObjTab("faqSubject", "SELECT * FROM ap_faqSubject WHERE " . MdlFaqSubject::sqlDisplayedObjects() . " AND " . $sqlThemeFilter . " ORDER BY dateCrea desc");

                $tmpTheme->subjectsNb = count($tmpTheme->subjectList);

                if ($tmpTheme->undefinedTheme == true && empty($tmpTheme->subjectsNb)) {
                    unset($vDatas["themeList"][$tmpKey]);
                }//Enleve le theme "sans theme" s'il n'y a aucun sujet correspondant..

                elseif ($tmpTheme->subjectsNb > 0) {
                    $tmpTheme->subjectLast = reset($tmpTheme->subjectList);
                }//reset: premier sujet de la liste (le + récent)

                //Nombre de messages & Dernier message : tous sujets confondus!

                $tmpTheme->messagesNb=$tmpTimeLastPost=0;

                foreach ($tmpTheme->subjectList as $tmpSubject) {


                    $messageList=$tmpSubject->getMessages();
					$tmpTheme->messagesNb+=count($messageList);



                    $tmpSubject->getMessages(true);

                   /*
                    if ($tmpSubject->messagesNb > 0) {
                        $tmpTheme->messagesNb += $tmpSubject->messagesNb;
                        if (empty($tmpTheme->timeLastPost) || $tmpSubject->timeLastPost > $tmpTheme->timeLastPost) {
                            $tmpTheme->messageLast = $tmpSubject->messageLast;
                            $tmpTheme->timeLastPost = $tmpSubject->tmeLastPost;


                        }
                   */
                    if(!empty($messageList)){
                        $lastMessage=reset($messageList);//1er message (le + récent)
                        if($tmpTimeLastPost<strtotime($lastMessage->dateCrea))   {$tmpTheme->messageLast=$lastMessage;  $tmpTimeLastPost=strtotime($lastMessage->dateCrea);}
                }

                }
            }
        } ////	AFFICHAGE DES SUJETS (D'UN THEME SPECIFIQUE?)
        else {
            $vDatas["displayFaq"] = "subjects";


            $vDatas["editTheme"] = (empty($vDatas["themeList"]) && MdlFaqTheme::addRight());
            //Liste les sujets


            if (Req::getParam("_idTheme") == "undefinedTheme") {
                $sqlThemeFilter = "AND (_idTheme is NULL or _idTheme=0)";
            }        //sujets "sans theme"

            elseif (Req::isParam("_idTheme")) {
                $sqlThemeFilter = "AND _idTheme=" . Db::formatParam("_idTheme");
            }    //sujets d'un theme précis

            else {
                $sqlThemeFilter = null;
            }                                            //tout les sujets

            $sqlDisplayedSubjects = "SELECT * FROM " . MdlFaqSubject::dbTable . " WHERE " . MdlFaqSubject::sqlDisplayedObjects() . " " . $sqlThemeFilter . " " . MdlFaqSubject::sqlSort();

            $vDatas["subjectsDisplayed"] = Db::getObjTab("faqSubject", $sqlDisplayedSubjects . " " . MdlFaqSubject::sqlPagination());

            $vDatas["subjectsTotalNb"] = count(Db::getTab($sqlDisplayedSubjects));

            //Pour chaque sujet : Nombre de messages & Dernier message

            foreach ($vDatas["subjectsDisplayed"] as $tmpSubject) {
                {
                    $tmpSubject->getMessages(true);
                }
            }
        }
        ////	THEME COURANT POUR LE MENU PATH
        if ($vDatas["displayFaq"] != "theme" && !empty($vDatas["themeList"])) {
            if (Req::getParam("_idTheme") == "undefinedTheme" || (is_object($curSubject) && empty($curSubject->_idTheme))) {
                $vDatas["curTheme"] = new MdlFaqTheme(["undefinedTheme" => true]);
            } elseif (is_object($curSubject) && !empty($curSubject->_idTheme)) {
                $vDatas["curTheme"] = self::getObj("faqTheme", $curSubject->_idTheme);
            } elseif (Req::getParam("_idTheme")) {
                $vDatas["curTheme"] = self::getObj("faqTheme", Req::getParam("_idTheme"));
            }
        }
        ////	AFFICHAGE
        static::$isMainPage = true;
        static::displayPage("VueIndexFaq.php", $vDatas);
    }

    /*
     * PLUGINS
     */
    public static function plugin($pluginParams)
    {
        $pluginsList = array();
        //Sujets
        foreach (MdlFaqSubject::getPluginObjects($pluginParams) as $objSubject) {
            $objSubject->pluginModule = self::moduleName;
            $objSubject->pluginIcon = self::moduleName . "/icon.png";
            $objSubject->pluginLabel = (!empty($objSubject->title)) ? $objSubject->title : Txt::reduce($objSubject->description);
            $objSubject->pluginTitle = $objSubject->displayAutor(true, true);
            $objSubject->pluginJsIcon = "redir('" . $objSubject->getUrl() . "',true);";
            $objSubject->pluginJsLabel = $objSubject->pluginJsIcon;
            $pluginsList[] = $objSubject;
        }
        //messages
        if ($pluginParams["type"] != "shortcut") {
            foreach (MdlFaqMessage::getPluginObjects($pluginParams) as $objMessage) {
                $objMessage->pluginModule = self::moduleName;
                $objMessage->pluginIcon = self::moduleName . "/icon.png";
                $objMessage->pluginLabel = (!empty($objMessage->title)) ? $objMessage->title : Txt::reduce($objMessage->description);
                $objMessage->pluginTitle = $objMessage->displayAutor(true, true);
                $objMessage->pluginJsIcon = "redir('" . $objMessage->getUrl("container") . "',true);";
                $objMessage->pluginJsLabel = $objMessage->pluginJsIcon;
                $pluginsList[] = $objMessage;
            }
        }
        return $pluginsList;
    }

    /*
     * AJAX : Active/désactive les notifications des messages par mail
     */
    public static function actionNotifyLastMessage()
    {
        $curSubject = Ctrl::getTargetObj();
        if ($curSubject->readRight()) {
            $usersNotifyLastMessage = Txt::txt2tab($curSubject->usersNotifyLastMessage);
            if ($curSubject->curUserNotifyLastMessage()) {
                $usersNotifyLastMessage = array_diff($usersNotifyLastMessage, [Ctrl::$curUser->_id]);
                echo "removeUser";
            } else {
                $usersNotifyLastMessage[] = Ctrl::$curUser->_id;
                echo "addUser";
            }
            Db::query("UPDATE ap_faqSubject SET usersNotifyLastMessage=" . Db::formatTab2txt($usersNotifyLastMessage) . " WHERE _id=" . $curSubject->_id);
        }
    }

    /*
     * ACTION : Edition des themes de sujet
     */
    public static function actionFaqThemeEdit()
    {
        ////	Droit d'ajouter un theme?
        if (MdlFaqTheme::addRight() == false) {
            static::lightboxClose(false);
        }
        ////	Validation de formulaire
        if (Req::isParam("formValidate")) {
            $curObj = Ctrl::getTargetObj();
            $curObj->controlEdit();
            //Modif d'un theme
            $_idSpaces = (!in_array("all", Req::getParam("spaceList"))) ? Txt::tab2txt(Req::getParam("spaceList")) : null;
            $curObj->createUpdate("title=" . Db::formatParam("title") . ", description=" . Db::formatParam("description") . ", color=" . Db::formatParam("color") . ", _idSpaces=" . Db::format($_idSpaces));
            //Ferme la page
            static::lightboxClose();
        }
        ////	Liste des themes
        $vDatas["themesList"] = MdlFaqTheme::getThemes(true);
        $vDatas["themesList"][] = new MdlFaqTheme();//nouveau theme vide
        foreach ($vDatas["themesList"] as $tmpKey => $tmpTheme) {
            if ($tmpTheme->editRight() == false) {
                unset($vDatas["themesList"][$tmpKey]);
            } else {
                $tmpTheme->tmpId = $tmpTheme->_targetObjId;
                $tmpTheme->createdBy = ($tmpTheme->isNew() == false) ? Txt::trad("creation") . " : " . Ctrl::getObj("user", $tmpTheme->_idUser)->display() : null;
            }
        }
        ////	Affiche la vue
        static::displayPage("VueFaqThemeEdit.php", $vDatas);
    }

    /*
     * ACTION : Edition d'un sujet
     */
    public static function actionFaqSubjectEdit()
    {
        //Init
        $curObj = Ctrl::getTargetObj();
        $curObj->controlEdit();
        if (MdlFaqSubject::addRight() == false) {
            self::noAccessExit();
        }
        ////	Formulaire validé
        if (Req::isParam("formValidate")) {
            //Enregistre & recharge l'objet
            $dateLastMessage = ($curObj->isNew()) ? ", dateLastMessage=" . Db::dateNow() : null;//Init "dateLastMessage" pour un nouveau sujet (classement des sujets)
            $curObj = $curObj->createUpdate("title=" . Db::formatParam("title") . ", description=" . Db::formatParam("description", "editor") . ", _idTheme=" . Db::formatParam("_idTheme") . ", usersConsultLastMessage=" . Db::formatTab2txt([Ctrl::$curUser->_id]) . " " . $dateLastMessage);
            //Notifie par mail & Ferme la page
            $mailNotif = Txt::reduce(strip_tags($curObj->description));
            if (!empty($curObj->title)) {
                $mailNotif = $curObj->title . "<br><br>" . $mailNotif;
            }
            $curObj->sendMailNotif($mailNotif);
            static::lightboxClose();
        }
        ////	Affiche la vue
        $vDatas["curObj"] = $curObj;
        if (Req::isParam("_idTheme")) {
            $curObj->_idTheme = Req::getParam("_idTheme");
        }
        $vDatas["themesList"] = MdlFaqTheme::getThemes();
        static::displayPage("VueFaqSubjectEdit.php", $vDatas);
    }

   
    public static function actionFaqMessageEdit()
    {
        //Init
        $curObj=Ctrl::getTargetObj();
        $curObj->controlEdit();
        ////	Formulaire validé
        if(Req::isParam("formValidate")){
            //Enregistre & recharge l'objet


            $idMessageParent=(Req::isParam("_idMessageParent"))  ?  ", _idMessageParent=".Db::formatParam("_idMessageParent")  :  null;//Rattaché à un message parent?

            $curObj=$curObj->createUpdate("title=".Db::formatParam("title").", description=".Db::formatParam("description","editor").$idMessageParent);
            //MAJ "dateLastMessage" & "usersConsultLastMessage" du sujet conteneur

            Db::query("UPDATE ap_faqSubject SET dateLastMessage=".Db::dateNow().", usersConsultLastMessage=".Db::formatTab2txt([Ctrl::$curUser->_id])." WHERE _id=".$curObj->_idContainer);

            //Notif "auto" si c'est un nouveau message (cf. "Me notifier par mail")

            if($curObj->isNewlyCreated()==false)	{$notifUserIds=null;}

            else{
                $notifUserIds=array_diff(Txt::txt2tab($curObj->containerObj()->usersNotifyLastMessage), [Ctrl::$curUser->_id]);//Users qui on demandé une notif .. et enlève l'auteur courant
                $notifUserIds=array_intersect($notifUserIds, $curObj->containerObj()->affectedUserIds());//Enlève les users qui n'ont plus accès au sujet en question
            }
            //Notifie par mail & Ferme la page

            $objLabel=Txt::reduce(strip_tags($curObj->description),1000);

            if(!empty($curObj->title))	{$objLabel=$curObj->title."<br><br>".$objLabel;}


            $curObj->sendMailNotif($objLabel, null, $notifUserIds);

            static::lightboxClose();
        }
        ////	Affiche la vue
        $vDatas["curObj"]=$curObj;
        $vDatas["messageParent"]=(strlen(Req::getParam("_idMessageParent"))>0)  ?  self::getObj("faqMessage",Req::getParam("_idMessageParent"))  :  null;
        static::displayPage("VueFaqMessageEdit.php",$vDatas);
    }
}
