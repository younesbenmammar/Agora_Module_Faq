<?php
/**
 * This file is part of the Agora-Project Software package.
 *
 * @copyright (c) Agora-Project Limited <https://www.agora-project.net>
 * @license GNU General Public License, version 2 (GPL-2.0)
 */


/*
 * Modele des sujets du forum
 */
class MdlFaqSubject extends MdlObject
{
    const moduleName="faq";
    const objectType="faqSubject";
    const dbTable="ap_faqSubject";
    const MdlObjectContent="MdlFaqMessage";
    const htmlEditorField="description";
    const nbObjectsByPage=30;
    const hasShortcut=true;
    const hasAttachedFiles=true;
    const hasNotifMail=true;
    const hasUsersLike=true;
    public static $requiredFields=array("description");
    public static $searchFields=array("title","description");
    public static $sortFields=array("dateLastMessage@@desc","dateLastMessage@@asc","dateCrea@@desc","dateCrea@@asc","dateModif@@desc","dateModif@@asc","_idUser@@asc","_idUser@@desc","title@@asc","title@@desc","description@@asc","description@@desc");

    /*
     * Liste des messages d'un sujet & Récupère le dernier message & le nombre de messages
     */
    public function getMessages($orderByDate=false)
    {
        //Récup la liste des messages et leur nombre
        $sqlSort=($orderByDate==true)  ?  "ORDER BY dateCrea desc"  :  MdlFaqMessage::sqlSort($this);
        $messageList=Db::getObjTab("faqMessage", "SELECT * FROM ap_faqMessage WHERE _idContainer=".$this->_id." ".$sqlSort);

        //récup le dernier message et le "time" du post
        $this->messagesNb=count($messageList);
        foreach($messageList as $tmpMessage)
        {
            if(empty($this->timeLastPost) || strtotime($tmpMessage->dateCrea)>$this->timeLastPost){
                $this->messageLast=$tmpMessage;
                $this->timeLastPost=strtotime($tmpMessage->dateCrea);
            }
        }
        //Renvoi la liste des messages
        return $messageList;
    }

    /*
     * L'user courant recoit-il des notifications d'ajout de nouveau message sur le sujet courant?
     */
    public function curUserNotifyLastMessage()
    {
        return in_array(Ctrl::$curUser->_id,Txt::txt2tab($this->usersNotifyLastMessage));
    }

    /*
     * L'user courant a-t-il consulté le dernier message?
     */
    public function curUserLastMessageIsNew()
    {
        return (Ctrl::$curUser->isUser() && !in_array(Ctrl::$curUser->_id,Txt::txt2tab($this->usersConsultLastMessage)));
    }

    /*
     * L'User courant a consulté le dernier message : MAJ DB
     */
    public function curUserConsultLastMessageMaj()
    {
        if($this->curUserLastMessageIsNew()){
            $usersConsultLastMessage=array_merge([Ctrl::$curUser->_id], Txt::txt2tab($this->usersConsultLastMessage));
            Db::query("UPDATE ap_faqSubject SET usersConsultLastMessage=".Db::formatTab2txt($usersConsultLastMessage)." WHERE _id=".$this->_id);
        }
    }

    /*
     * SURCHARGE : Droit d'ajouter un nouveau sujet
     */
    public static function addRight()
    {
        return (Ctrl::$curUser->isAdminCurSpace() || (Ctrl::$curUser->isUser() && Ctrl::$curSpace->moduleOptionEnabled(self::moduleName,"ajout_sujet_admin")==false));
    }

    /*
     * SURCHARGE : Url d'accès (sujet d'un thème particulier ?)
     */
    public function getUrl($display=null)
    {
        //Url "container" : theme
        if($display=="container"){
            if(!empty($this->_idTheme))					{return "?ctrl=".static::moduleName."&_idTheme=".$this->_idTheme;}	//theme spécifique
            elseif(count(MdlForumTheme::getThemes())>0)	{return "?ctrl=".static::moduleName."&_idTheme=undefinedTheme";}	//"sans theme"
            else										{return "?ctrl=".static::moduleName;}								//accueil du forum
        }
        //Url "parent" : normal
        return parent::getUrl($display);
    }
}
